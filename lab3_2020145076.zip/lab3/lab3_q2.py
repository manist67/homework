# author : Seung Min Lee
# since : 2023-03-25
# purpose : the answer of qustion2

# A is -10; Brackets are calculated first. 
# B is 5; % is modular operator.
# C is -7; // is integer divide operator and ** is power operator.

print(-12)