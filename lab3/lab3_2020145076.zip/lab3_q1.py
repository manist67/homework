# author : Seung Min Lee
# since : 2023-03-25
# purpose : the answer of qustion no.13

print(99)
