# lab5_q2.py
# n = 10 , k = 20

# (a) (n > 10) and (k == 20)
print(False)

# (b) (n > 10) or (k == 20)
print(True)

# (c) not ((n > 10) and (k == 20))
print(True)

# (d) not (n > 10) and not(k == 20)
print(False)

# (e) (n > 10) or (k == 10 or k != 5)
print(True)