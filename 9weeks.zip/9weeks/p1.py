string_format = '{0: >9}{1: >4}{2: >6}{3: >4}{4: >7}'
print(string_format.format("LECTURE", "DAY", "START", "END", "CREDIT"))
print(string_format.format("YCS1012-1", "Mon", "1", "3", "3"))
print(string_format.format("ABC1234-1", "Tue", "3", "5", "3"))
print(string_format.format("ENG2023-1", "Fri", "6", "8", "3"))
