# lab5_q1.py

# (a) x or False
print(True)

# (b) x and True
print(True)

# (c) not (x or False)
print(False)

# (d) not (x and True)
print(False)