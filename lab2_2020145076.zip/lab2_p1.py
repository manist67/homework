base = int(input("What Base? "))
power = int(input("What Power of {}? ".format(base)))

print("{} to the power of {} is {}".format(base, power, base ** power))
