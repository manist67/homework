print("This program will convert degrees Celsius to Fahrenheit")
c = float(input("Enter degrees Celsius: "))
f = (c * 9/5) + 32
print("{} degrees Celsius equals {:.1f} degrees Fahrenheit".format(c, f))
